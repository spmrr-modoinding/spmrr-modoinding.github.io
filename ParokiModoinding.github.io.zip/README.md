# Website Paroki SP Maria Ratu Rosari - Modoinding

Website resmi Paroki Santa Perawan Maria Ratu Rosari Modoinding.

## 📁 Struktur Halaman
- **Beranda**: Profil pastor & renungan harian
- **Agenda**: Agenda mingguan paroki
- **Angelus**: Teks Doa Malaikat Tuhan & pengingat waktu
- **Pastor**: Status kehadiran pastor
- **Statistik**: Data umat per wilayah (otomatis ditambahkan via JavaScript)

## 🚀 Dibuat Dengan
- HTML, CSS, JavaScript
- GitHub Pages untuk hosting gratis

## 🎯 Tujuan
Menyediakan informasi dan sarana devosi online bagi seluruh umat Paroki Modoinding.

---

🕊️ *Dibuat oleh Sekretariat Paroki — 2025*